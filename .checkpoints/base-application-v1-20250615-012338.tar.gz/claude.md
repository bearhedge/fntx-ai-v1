# FNTX.ai Project Context File (claude.md)

## Project Overview
**Project Name:** FNTX.ai - Autonomous Options Trading Agent  
**Version:** v1.0.0-alpha  
**Last Updated:** December 2024  
**Primary Contact:** Jimmy Hou / Development Team  
**Project Type:** AI-Driven Financial Trading System with GPU Acceleration

### Project Mission
Transform static capital into a dynamic, income-generating machine through an autonomous AI agent that executes daily SPY options selling strategies. FNTX.ai serves as a personal "digital ATM" that not only manages funds but actively generates returns through intelligent, automated trading strategies, all secured and transparently recorded on blockchain.

### Core Vision
Empower individuals with a personal, AI-driven "digital ATM" that actively generates returns through autonomous, intelligent SPY options selling strategies, secured and transparently recorded on the blockchain. This system aims to democratize access to sophisticated trading strategies while creating a decentralized, collaborative financial ecosystem that can cut out traditional intermediaries.

## System Architecture

### Agentic AI Architecture with MCP

FNTX.ai integrates Anthropic's Model Context Protocol (MCP) to enable memory-based reasoning and long-horizon learning for each trading agent. Each core agent operates with modular agentic code patterns, facilitating autonomy, coordination, and self-improvement.

#### Core Agent Types:

| Agent Role | Description | Memory Scope | MCP Integration |
|------------|-------------|--------------|-----------------|
| **StrategicPlannerAgent** | Uses Claude Code to analyze market regime and select macro strategies | Full contextual memory across all sessions | MCP persistent context API |
| **TacticalExecutorAgent** | Converts strategy into concrete trades, sizing, and timing | Rolling 30-day performance memory | MCP short-term optimization memory |
| **EvaluatorAgent** | Monitors outcomes and injects learnings into strategy memory | Aggregated weekly performance summaries | MCP reflection and learning database |
| **EnvironmentWatcherAgent** | Tracks SPY, VIX, macro signals, market regime changes | Long-horizon pattern recognition memory | MCP market context database |
| **RewardModelAgent** | Learns preferences from performance, user feedback, and RLHF | Global performance and preference memory | MCP user preference learning |

#### MCP Integration Points
- **Memory Persistence:** Each agent saves outcomes and rationales using MCP-compatible JSON memory schema
- **Shared Knowledge Graph:** Agent knowledge is synchronized via context API for cross-agent learning
- **Long-Horizon Learning:** Historical trades, success/failure patterns, and edge cases are reused for generalization
- **Inter-Agent Communication:** Agents share insights through structured MCP context sharing

### Traditional AI Agent Stack
- **High-Level Strategy AI:** Claude Code (strategic decision-making and market analysis)
- **Custom Models:** GPU-accelerated specialized models (when available)
- **Granular Decision AI:** Local fine-tuned models for tactical execution
- **Execution Interface:** Interactive Brokers API (IBKR)
- **Blockchain Layer:** Immutable record keeping and audit trails
- **Frontend:** React + TypeScript clean chatbot UI

### Core Components
1. **MCP-Enabled Agentic Execution Engine**
2. **Blockchain-Secured Records System**
3. **Minimalist User Interface**
4. **Streamlined Withdrawal Management**
5. **Explainable AI (XAI) Module**
6. **Advanced Analytics & Risk Management**
7. **Agent Memory & Learning System (MCP)**
8. **Self-Improving Decision Framework**

## Technical Specifications

### Technology Stack
- **AI Frameworks:** Claude Code API, PyTorch/TensorFlow (GPU-accelerated when available)
- **MCP Integration:** Anthropic MCP for persistent agent memory and context
- **Agent Framework:** LangChain/AutoGen for multi-agent coordination
- **Trading API:** Interactive Brokers (IBKR) API
- **Blockchain:** Ethereum/Polygon (TBD based on gas costs and requirements)
- **Frontend:** React + TypeScript + Vite + Tailwind CSS + shadcn/ui
- **Backend:** Python Flask/FastAPI with GPU support
- **Database:** SQLite (development) → PostgreSQL (production) + Blockchain storage + Vector DB for agent memory
- **Real-time Data:** WebSocket connections for market data
- **Model Serving:** NVIDIA Triton (production) / Direct inference (development)
- **Memory Storage:** Redis for agent state, Vector database (Pinecone/Weaviate) for long-term memory

### Hardware Requirements
- **Development:** Standard development machine, optional NVIDIA GPU (8GB+ VRAM)
- **Production:** Cloud infrastructure with optional GPU acceleration
- **Memory:** 16GB+ RAM (32GB+ for GPU training)
- **Storage:** SSD for fast data access

### Trading Strategy Focus
- **Primary Asset:** SPY (S&P 500 ETF) options
- **Strategy Type:** Options selling (premium collection)
- **Execution Frequency:** Daily automated trades
- **Risk Management:** 3x stop-loss, 50% take-profit rules
- **AI Enhancement:** Continuous improvement through data analysis

## Core Features & Implementation

### 1. Autonomous Execution Engine

#### Multi-tiered AI Architecture
- **Strategic Layer (Claude Code):** Market analysis, strategy selection, risk assessment
- **Custom Model Layer (Optional GPU):** Specialized models for volatility prediction and risk assessment
- **Tactical Layer:** Trade timing, position sizing, execution decisions
- **Integration Layer:** IBKR API connectivity and order management

#### Key Capabilities
- **Automated Trade Execution:** Execute trades based on predefined risk parameters without human intervention
- **Strategic Waiting Periods:** Enforce 1.5-5 hour waiting periods with documented rationale
- **Risk Management Automation:** Implement automatic stop-loss (3x premium) and take-profit (50% premium) orders
- **Market Condition Analysis:** Real-time SPY market analysis and volatility assessment
- **GPU-Accelerated Inference:** When available, use GPU for real-time decision making

### 2. Advanced AI Models (Progressive Implementation)

#### Phase 1: Core Models
- **Volatility Prediction:** LSTM networks for implied volatility forecasting
- **Risk Assessment:** Real-time portfolio risk evaluation
- **Market Regime Detection:** Classification of current market conditions

#### Phase 2: Enhanced Models (GPU-Accelerated)
- **Price Direction Models:** CNN+LSTM ensembles for movement prediction
- **Options Mispricing Detection:** Deep networks for arbitrage identification
- **Reinforcement Learning:** Adaptive risk management optimization

#### Training Infrastructure (When Implemented)
- **Data Pipeline:** Efficient preprocessing with RAPIDS (GPU) or pandas (CPU)
- **Training Framework:** PyTorch with CUDA optimization when available
- **Model Versioning:** MLflow for experiment tracking
- **Deployment:** TensorRT optimization for production inference

### 2.5. MCP-Enabled Agent Learning & Memory System

#### Agent Learning Cycle (MCP-based)
The system implements a continuous learning loop where each agent maintains persistent memory through MCP and improves performance through structured reflection:

1. **Per-Trade Memory Logging:** Each agent logs rationale, market state, and outcome using MCP-compatible JSON schema
2. **EvaluatorAgent Summarization:** Weekly success/failure patterns are summarized and stored in agent memory
3. **PlannerAgent Reflection:** Claude Code performs strategic critique on trade clusters and market performance
4. **TacticalAgent Update:** Modifies heuristics, thresholds, and sizing based on reflection outcomes
5. **Cross-Agent Knowledge Sharing:** Insights are shared between agents through MCP context synchronization

#### MCP Memory Schema
Each agent maintains structured memory that persists across sessions:

```json
{
  "agent_id": "StrategicPlannerAgent",
  "session_id": "2024-12-12",
  "memory_type": "trade_analysis",
  "timestamp": "2024-12-12T14:30:00Z",
  "context": {
    "strategy": "SPY 0DTE Put Selling",
    "market_regime": "Low volatility, bullish trend",
    "rationale": "VIX < 14, strong support at 445, selling 440P for premium collection",
    "confidence": 0.79,
    "expected_outcome": "85% probability of profit, max loss 3x premium"
  },
  "execution": {
    "symbol": "SPY",
    "option_type": "PUT",
    "strike": 440.0,
    "expiration": "2024-12-12",
    "premium_collected": 0.75,
    "contracts": 10
  },
  "outcome": {
    "status": "CLOSED_PROFIT",
    "actual_profit": 750.0,
    "closure_reason": "EXPIRED_WORTHLESS",
    "holding_period": "4h 30m",
    "market_move": "SPY closed at 447.50"
  },
  "learning_signals": {
    "strategy_validation": "POSITIVE",
    "sizing_appropriateness": "OPTIMAL", 
    "timing_accuracy": "GOOD",
    "market_read": "ACCURATE",
    "improvement_areas": ["Could have sized larger given high confidence"]
  },
  "next_session_context": {
    "successful_patterns": ["Low VIX + strong support = high win rate"],
    "risk_insights": ["Market moved faster than expected, consider tighter stops"],
    "strategy_adjustments": ["Increase size multiplier when confidence > 0.80 and VIX < 12"]
  }
}
```

#### Self-Improving Mechanisms

**Nightly Reflection Process:**
- **Data Aggregation:** All daily trades and market observations are compiled
- **Pattern Recognition:** Claude Code analyzes trade clusters for success/failure patterns
- **Strategy Adjustment:** Agents update internal parameters based on performance analysis
- **Memory Consolidation:** Key insights are stored in long-term MCP memory for future reference

**Weekly Strategy Review:**
- **Performance Analysis:** Comprehensive review of weekly P&L, win rate, and risk metrics
- **Market Regime Analysis:** Assessment of strategy performance across different market conditions
- **Agent Coordination:** Cross-agent sharing of insights and strategy refinements
- **Model Updates:** Fine-tuning of decision thresholds and risk parameters

#### Real-Time Learning Integration
- **Trade Outcome Feedback:** Immediate incorporation of trade results into agent memory
- **Market Condition Updates:** Continuous updating of market regime assessments
- **Risk Adjustment:** Dynamic adjustment of position sizing based on recent performance
- **Strategy Selection:** Preference learning for optimal strategy selection based on market conditions

### 3. Blockchain-Secured Records System

#### Immutable Audit Trail Features
- **Trade Verification:** Every trade recorded on blockchain with timestamp
- **Decision Logging:** AI decision rationale stored immutably
- **Performance Tracking:** Real-time calculation of key metrics
- **Compliance Records:** Complete audit trail for regulatory compliance
- **Model Performance:** Track model versions and prediction accuracy

#### Performance Metrics Tracking
- **DPI (Distributions to Paid-In Capital):** Cash returned vs initial investment
- **TVPI (Total Value to Paid-In Capital):** Total portfolio value vs investment
- **RVPI (Residual Value to Paid-In Capital):** Current holdings value vs investment
- **Win Rate:** Percentage of profitable trades
- **Average Return per Trade:** Mean profit/loss per executed strategy
- **Sharpe Ratio:** Risk-adjusted performance measurement

#### AI Training Data Pipeline
- Blockchain records serve as training dataset for continuous model improvement
- RLHF (Reinforcement Learning from Human Feedback) integration
- Network effect data aggregation across user base
- Privacy-preserving federated learning approach

### 4. Minimalist User Interface

#### Design Principles
- **Clean Chatbot UI:** Monochromatic, conversation-based interface
- **Real-time Status:** Live position monitoring and risk indicators
- **Explainable Decisions:** Clear AI reasoning for every action
- **Mobile-First:** Responsive design for mobile accessibility
- **Progressive Enhancement:** Optional advanced features for power users

#### Key UI Components
- Chat interface for user interaction
- Portfolio dashboard with key metrics
- Position status indicators (active/pending/closed)
- Risk meter and exposure visualization
- Transaction history with AI explanations
- Analytics dashboard (expandable for detailed insights)

### 5. Withdrawal Management System

#### Automated Recommendations
- Performance-based withdrawal suggestions
- Optimal timing recommendations based on market conditions
- Risk-adjusted withdrawal amounts
- Predictive liquidity analysis

#### Fund Management Features
- **Available Funds Calculator:** Real-time fund availability breakdown
- **Withdrawal Processing:** Streamlined, one-click withdrawal process
- **Liquidity Management:** Ensure sufficient capital for ongoing operations
- **Tax Optimization:** Consider tax implications in withdrawal timing

## AI Agent Behavior & Decision Making

### Decision Framework Hierarchy
1. **Risk Assessment:** Evaluate current market volatility and portfolio exposure
2. **Strategy Selection:** Choose optimal SPY options selling strategy
3. **Position Sizing:** Calculate appropriate trade size based on available capital
4. **Timing Optimization:** Determine optimal entry and exit points
5. **Execution:** Place orders through IBKR API
6. **Monitoring:** Continuous position monitoring and adjustment

### Explainable AI Requirements
Every AI decision must include:
- **Rationale:** Clear explanation of why the decision was made
- **Risk Assessment:** Identified risks and mitigation strategies
- **Expected Outcome:** Projected results and probability estimates
- **Market Context:** Current market conditions influencing the decision
- **Historical Reference:** Similar past scenarios and outcomes
- **Confidence Level:** AI confidence in the decision with uncertainty bounds

### Risk Management Protocols
- **Maximum Daily Risk:** Limit daily exposure to 2% of total capital
- **Position Limits:** Maximum 3 concurrent positions
- **Volatility Thresholds:** Halt trading when VIX > 35 or during extreme conditions
- **Stop-Loss Automation:** Automatic exit at 3x premium loss
- **Take-Profit Automation:** Close positions at 50% premium capture
- **Circuit Breakers:** Emergency halt mechanisms for unusual market conditions

## Development Workflow

### Current Implementation (v1.0.0-alpha)
```
fntx-ai-v10/
├── src/                    # React frontend application
│   ├── components/         # UI components (Chat, Trading, Analytics)
│   ├── pages/             # Route pages
│   └── types/             # TypeScript type definitions
├── backend/               # Main FastAPI backend server
├── agents/                # AI trading agents and logic
│   ├── executor.py        # Trade execution agent
│   ├── planner.py         # Strategic planning agent
│   ├── evaluator.py       # Performance evaluation agent
│   ├── environment_watcher.py # Market monitoring agent
│   ├── reward_model.py    # Learning and preference agent
│   ├── worker.py          # Background processing
│   ├── memory/            # MCP-compatible agent memory
│   │   ├── planner_memory.json
│   │   ├── executor_memory.json
│   │   ├── evaluator_memory.json
│   │   └── shared_context.json
│   ├── goals/             # High-level agentic goals
│   │   ├── profit_targets.json
│   │   ├── risk_limits.json
│   │   └── strategy_preferences.json
│   └── reflection/        # Self-improvement and learning logic
│       ├── nightly_analysis.py
│       ├── weekly_review.py
│       └── performance_insights.json
├── database/              # Database configuration and models
└── public/               # Static assets and resources
```

### Development Commands
```bash
# Start development environment
npm start                  # All services
npm run dev               # Frontend only
python backend/main.py    # Backend only

# Agent management
python agents/planner.py  # Start strategic planner agent
python agents/executor.py # Start trade execution agent
python agents/evaluator.py # Start performance evaluation agent

# Learning and reflection
python agents/reflection/nightly_analysis.py  # Run nightly learning cycle
python agents/reflection/weekly_review.py     # Run weekly strategy review
python agents/memory/sync_mcp_context.py      # Synchronize agent memory

# Data and testing
npm run lint              # Code linting
npm test                  # Run tests
npm run build            # Production build
npm run test:agents       # Test agent behavior and memory
```

## Blockchain Integration

### Smart Contract Functions
- **Trade Recording:** Immutable logging of all trade executions
- **Performance Calculation:** Automated metric calculations
- **Access Control:** User authentication and authorization
- **Withdrawal Processing:** Secure fund transfer mechanisms
- **Model Performance Tracking:** Record model versions and accuracy

### Enhanced Data Structure
```json
{
  "tradeId": "unique_identifier",
  "timestamp": "ISO_8601_datetime",
  "userId": "user_identifier",
  "strategy": "SPY_options_selling",
  "aiDecision": {
    "rationale": "explanation_text",
    "confidence": 0.85,
    "marketConditions": "analysis_summary",
    "modelVersion": "v1.2.3",
    "riskScore": 0.23
  },
  "execution": {
    "symbol": "SPY",
    "optionType": "PUT/CALL",
    "strike": 445.0,
    "expiration": "2024-12-20",
    "premium": 2.50,
    "contracts": 5
  },
  "outcome": {
    "status": "OPEN/CLOSED/EXPIRED",
    "profit_loss": 125.50,
    "closure_reason": "TAKE_PROFIT",
    "holdingPeriod": "4h 23m"
  },
  "performance": {
    "returnPercent": 0.025,
    "annualizedReturn": 0.15,
    "sharpeContribution": 0.08
  }
}
```

## Security & Compliance

### Financial Security
- **API Key Management:** Secure storage of IBKR credentials using environment variables
- **Transaction Encryption:** End-to-end encryption for all trades
- **Multi-factor Authentication:** User account protection
- **Cold Storage:** Secure storage of user funds when not actively trading
- **Audit Logging:** Comprehensive logging of all system activities

### Regulatory Compliance
- **Know Your Customer (KYC):** User identity verification processes
- **Anti-Money Laundering (AML):** Transaction monitoring and reporting
- **Financial Records:** Maintain records per regulatory requirements (7+ years)
- **Risk Disclosure:** Clear communication of trading risks and disclaimers
- **Model Transparency:** Explainable AI for regulatory compliance

### Data Privacy
- **User Data Protection:** GDPR/CCPA compliance measures
- **Blockchain Privacy:** Balance transparency with user privacy
- **Audit Logs:** Secure logging without exposing sensitive data
- **Data Minimization:** Collect only necessary data for operations

## Deployment Strategy

### Development Environment
- **Local Development:** SQLite database, mock trading mode
- **Testing:** Paper trading with real market data
- **Staging:** Limited real trading with small amounts

### Production Environment
- **Database:** PostgreSQL with backup and replication
- **Infrastructure:** Cloud deployment with auto-scaling
- **Monitoring:** Comprehensive logging and alerting
- **Backup:** Multi-region backup and disaster recovery

### Progressive Rollout
1. **Alpha (Current):** Core functionality, limited users
2. **Beta:** Enhanced features, expanded user base
3. **Production:** Full feature set, public availability
4. **Scale:** Multi-asset support, advanced features

## Success Metrics & KPIs

### Financial Performance
- **Alpha Generation:** Excess returns over SPY benchmark
- **Risk-Adjusted Returns:** Sharpe ratio > 1.5 target
- **Consistency:** Positive monthly returns > 70%
- **Drawdown Management:** Maximum drawdown < 15%
- **Capital Efficiency:** Return on deployed capital > 20% annually

### Operational Excellence
- **Autonomous Execution Rate:** > 95% trades without intervention
- **System Uptime:** 99.9% availability target
- **Decision Latency:** < 5 seconds for trade decisions
- **API Reliability:** < 0.1% failed trade executions

### User Experience
- **User Retention:** > 85% monthly retention
- **Satisfaction Score:** > 4.5/5 user rating
- **Support Requests:** < 2% of trades require support
- **Onboarding Time:** < 30 minutes to first trade

## Risk Management & Monitoring

### Technical Risk Controls
- **Position Limits:** Hard limits on exposure per strategy
- **Market Circuit Breakers:** Automatic halt during extreme volatility
- **API Failsafes:** Backup systems for connectivity issues
- **Model Validation:** Continuous monitoring of model performance
- **Slippage Controls:** Limits on execution price deviation

### Business Continuity
- **Disaster Recovery:** 4-hour RTO, 1-hour RPO targets
- **Data Backup:** Real-time blockchain backup, daily database backup
- **Team Redundancy:** Cross-trained team members for critical functions
- **Financial Reserves:** 6-month operating expenses in reserve

## Future Roadmap

### Phase 1: Foundation with Basic Agents (Q4 2024 - Q1 2025)
- Complete core SPY options trading automation
- Implement basic MCP agent memory system
- Deploy StrategicPlannerAgent and TacticalExecutorAgent
- Launch minimal viable chat interface
- Achieve consistent profitability in paper trading
- Basic nightly reflection and learning loops

### Phase 2: Advanced Learning & Intelligence (Q2 2025 - Q3 2025)
- Deploy full 5-agent system with MCP integration
- Implement GPU-accelerated model training
- Add sophisticated reflection and self-improvement mechanisms
- Launch cross-agent knowledge sharing
- Advanced risk management with adaptive parameters
- Multi-timeframe analysis with agent coordination

### Phase 3: Expansion & Optimization (Q4 2025 - Q1 2026)
- Support additional asset classes (QQQ, IWM options)
- Custom strategy configuration through agent preferences
- Advanced analytics dashboard with agent insights
- Mobile application with agent chat interface
- Federated learning across user base
- Agent marketplace for strategy sharing

### Phase 4: Ecosystem & Scaling (Q2 2026+)
- Third-party agent integration marketplace
- Community features and social trading with agent insights
- White-label platform offering with customizable agents
- Institutional-grade features with multi-agent portfolios
- Advanced MCP features for enterprise clients
- Cross-platform agent deployment and scaling

## Development Standards

### Code Quality
- **TypeScript:** Strict typing for all frontend components
- **Python:** PEP 8 compliance with type hints
- **Testing:** 90%+ code coverage requirement
- **Documentation:** Comprehensive JSDoc/Docstrings
- **Security:** Regular penetration testing and audits

### AI/ML Standards
- **Model Versioning:** Semantic versioning for all models
- **Experiment Tracking:** MLflow for all training runs
- **Data Validation:** Automated data quality checks
- **Model Monitoring:** Real-time performance tracking
- **Ethical AI:** Bias detection and fairness metrics

### Agentic Development Standards

#### MCP Integration Guidelines
- **Memory Schema Consistency:** All agents must use standardized JSON schema for MCP memory
- **Context Synchronization:** Regular synchronization of shared knowledge across agents
- **Memory Persistence:** Critical agent memories must be backed up to blockchain
- **Privacy Protection:** Sensitive user data must be encrypted in agent memory
- **Memory Cleanup:** Automated cleanup of stale or redundant memory entries

#### Agent Behavior Standards
- **Explainable Decisions:** Every agent decision must include clear rationale and confidence levels
- **Goal Alignment:** All agent actions must align with user profit objectives and risk tolerance
- **Fail-Safe Mechanisms:** Agents must have built-in safety stops for extreme market conditions
- **Performance Accountability:** Each agent must track and report its contribution to overall performance
- **Continuous Learning:** Agents must incorporate new information and improve over time

#### Inter-Agent Communication
- **Structured Messaging:** Use standardized message formats for agent communication
- **Conflict Resolution:** Clear protocols for resolving conflicting agent recommendations
- **Knowledge Sharing:** Efficient sharing of successful patterns and failure modes
- **Coordination Protocols:** Defined handoff procedures between agents for trade execution
- **Emergency Coordination:** Rapid communication during market emergencies or system failures

#### Agent Testing & Validation
- **Behavioral Testing:** Comprehensive testing of agent decision-making under various market conditions
- **Memory Integrity:** Regular validation of agent memory consistency and accuracy
- **Performance Benchmarking:** Standardized metrics for evaluating agent contribution to system performance
- **Adversarial Testing:** Testing agent robustness against unusual market scenarios
- **Integration Testing:** Comprehensive testing of multi-agent coordination and communication

## AI Assistant Behavior & Development Standards

### AI Behavior Rules

#### Core Behavior Principles
- **Complete Resolution Focus:** You are an agent - please keep going until the user's query is completely resolved, before ending your turn and yielding back to the user. Only terminate your turn when you are sure that the problem is solved.
- **Evidence-Based Responses:** If you are not sure about file content or codebase structure pertaining to the user's request, use your tools to read files and gather the relevant information: do NOT guess or make up an answer.
- **Extensive Planning & Reflection:** You MUST plan extensively before each function call and reflect extensively on the outcomes of the previous function calls. DO NOT do this entire process by making function calls only, as this can impair your ability to solve the problem and think insightfully.

#### Development Approach
- **Senior Full Stack Expertise:** You are a Senior Full Stack Developer and an Expert in Vue, NestJS, JavaScript, TypeScript, HTML, SCSS and modern UI/UX frameworks (e.g., TailwindCSS, NuxtUI, Vuetify).
- **Thoughtful Analysis:** You are thoughtful, give nuanced answers, and are brilliant at reasoning. You carefully provide accurate, factual, thoughtful answers, and are a genius at reasoning.
- **Requirements Compliance:** Follow the user's requirements carefully & to the letter.
- **Step-by-Step Planning:** First think step-by-step - describe your plan for what to build in pseudocode, written out in great detail. Confirm, then write code!

### Coding Standards & Principles

#### Best Practice Implementation
- **Code Quality:** Always write correct, best practice, KISS, DRY, SOLID, YAGNI principles, bug free, fully functional and working code.
- **Component Architecture:** Avoid creating very large Vue components. When possible, extract functionality into separate sub-components.
- **Project Adaptation:** When working on an existing project, adapt to the existing conventions. If there's not enough context in the prompt to know what the conventions in the current project are, you MUST proactively read other files to find out.
- **Convention Learning:** When asked to do something / create some kind of code, first read code of the same kind in the project so you know what's the project's syntax and practices.
- **Type Safety:** Before creating types or interfaces, first search through the project as the required types might already exist.
- **Migration Management:** Before creating migrations on backend, check what the correct command is in the package.json. After creation, check if the created migration contains only the added fields, otherwise remove the rest as the generator may add garbage.

#### Code Completeness Standards
- **Readability Focus:** Focus on easy and readability code, over being performant.
- **Full Implementation:** Fully implement all requested functionality.
- **No Placeholders:** Leave NO to do's, placeholders or missing pieces.
- **Thorough Verification:** Ensure code is complete! Verify thoroughly finalized.
- **Proper Imports:** Include all required imports, and ensure proper naming of key components.
- **Concise Communication:** Be concise Minimize any other prose.

#### Problem Solving Approach
- **Honest Assessment:** If you think there might not be a correct answer, you say so.
- **Knowledge Boundaries:** If you do not know the answer, say so, instead of guessing.
- **Option Presentation:** When you want to show different options to solve an issue, do so WITHOUT implementing every option. First ask the user which one they would prefer.
- **Markdown Communication:** Every non-code part of your response should be written using Markdown, for better legibility.
- **Documentation Usage:** When using frameworks / UI libraries, you may use context to check the documentation on what components to use for the required task and how to use them correctly.

### Critical Implementation Guidelines

#### Scope Management (IMPORTANT #1)
- **Limited Scope:** Limit yourself to what you were asked to do. DO NOT REFACTOR / REWRITE code unless asked to.
- **Recommendation Protocol:** Instead, you MAY emit any recommendations you have at the end of your message (or you may do it at the start, and ask for confirmation, if you feel convenient).

#### User-Centric Approach (IMPORTANT #2)
- **Non-Technical User Focus:** The user is not a software engineer. Focus on what he asked you to change from the user's vision and provide options on the logical constructs or engineering solutions.
- **Requested Changes Only:** Do not fix or change things that haven't been asked you to.

#### Robust Implementation (IMPORTANT #3)
- **Careful Implementation:** Every change you implement must be carefully thought, and the implementation MUST BE ROBUST, unless specified otherwise by the user.
- **Design-First Approach:** You should plan and design a robust implementation of the desired action, following the principles stated above, and present it to the user, asking at the end if they would like to proceed with the implementation or make changes to it.

This claude.md file serves as the definitive reference for FNTX.ai development, ensuring all team members and AI assistants understand the project's vision, technical requirements, and implementation strategy. The system balances ambitious AI capabilities with practical implementation constraints, enabling rapid iteration and deployment while maintaining the flexibility to scale advanced features as needed.