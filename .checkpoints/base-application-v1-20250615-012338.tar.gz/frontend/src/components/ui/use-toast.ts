
// Re-export the toast hook from the main hooks folder
export { useToast, toast } from "@/hooks/use-toast";
