// Orchestrator API Client for Frontend Integration
// This connects your existing chatbot to the agent orchestration system

export interface TradeJourney {
  trade_id: string;
  user_request: string;
  initiated_at: string;
  current_phase: string;
  steps: TradeStep[];
  risk_assessment: RiskAssessment;
  final_outcome?: FinalOutcome;
  execution_time: number;
  errors: string[];
}

export interface TradeStep {
  timestamp: string;
  agent: string;
  action: string;
  rationale: string;
  status: 'pending' | 'running' | 'completed' | 'error' | 'skipped';
  confidence_level: number;
  risk_assessment: Record<string, any>;
  execution_time: number;
  error_message?: string;
}

export interface RiskAssessment {
  overall_risk: string;
  confidence_level: number;
  max_exposure: number;
  stop_loss_level: number;
}

export interface FinalOutcome {
  success: boolean;
  message: string;
  completed_at: string;
  total_steps: number;
  agent_statuses: Record<string, string>;
}

export class OrchestratorClient {
  private baseUrl: string;

  constructor(baseUrl = 'http://localhost:8002') {
    this.baseUrl = baseUrl;
  }

  // Start a new trade orchestration
  async startTradeOrchestration(userMessage: string): Promise<{trade_id: string, status: string}> {
    const response = await fetch(`${this.baseUrl}/api/orchestrator/execute`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        user_request: userMessage,
        timestamp: new Date().toISOString(),
        risk_tolerance: 'moderate',
        max_exposure: 500.0
      }),
    });

    if (!response.ok) {
      throw new Error(`Failed to start orchestration: ${response.statusText}`);
    }

    return response.json();
  }

  // Get trade journey details
  async getTradeJourney(tradeId: string): Promise<TradeJourney> {
    const response = await fetch(`${this.baseUrl}/api/orchestrator/journey/${tradeId}`);
    
    if (!response.ok) {
      throw new Error(`Failed to get trade journey: ${response.statusText}`);
    }

    return response.json();
  }

  // Get current active journey
  async getCurrentJourney(): Promise<TradeJourney> {
    const response = await fetch(`${this.baseUrl}/api/orchestrator/current-journey`);
    
    if (!response.ok) {
      throw new Error(`Failed to get current journey: ${response.statusText}`);
    }

    return response.json();
  }

  // Poll for trade updates
  async pollTradeProgress(
    tradeId: string, 
    onUpdate: (journey: TradeJourney) => void,
    onComplete: (journey: TradeJourney) => void,
    onError: (error: string) => void
  ): Promise<void> {
    const poll = async () => {
      try {
        const journey = await this.getTradeJourney(tradeId);
        onUpdate(journey);

        // Check if trade is completed
        if (journey.final_outcome || journey.current_phase === 'completed' || journey.current_phase === 'failed') {
          onComplete(journey);
          return;
        }

        // Continue polling
        setTimeout(poll, 2000); // Poll every 2 seconds
      } catch (error) {
        onError(error instanceof Error ? error.message : 'Unknown error');
      }
    };

    poll();
  }

  // Check if message should trigger orchestration
  isTradeRequest(message: string): boolean {
    const tradeKeywords = [
      'trade', 'buy', 'sell', 'option', 'spy', 'put', 'call',
      'strategy', 'market', 'best', 'opportunity', 'premium',
      'selling', 'execute', 'position', 'risk'
    ];

    const messageLower = message.toLowerCase();
    return tradeKeywords.some(keyword => messageLower.includes(keyword));
  }

  // Format journey for chat display
  formatJourneyForChat(journey: TradeJourney): string {
    let message = `🚀 **Trade Journey: ${journey.trade_id}**\n\n`;
    message += `**Request:** ${journey.user_request}\n`;
    message += `**Phase:** ${journey.current_phase}\n`;
    message += `**Risk Level:** ${journey.risk_assessment.overall_risk}\n`;
    message += `**Confidence:** ${(journey.risk_assessment.confidence_level * 100).toFixed(0)}%\n\n`;

    if (journey.steps.length > 0) {
      message += `**Progress:**\n`;
      journey.steps.forEach((step, index) => {
        const statusEmoji = {
          pending: '⏳',
          running: '🔄',
          completed: '✅',
          error: '❌',
          skipped: '⏭️'
        }[step.status] || '📍';

        message += `${statusEmoji} **${step.agent.replace('Agent', '')}**: ${step.action}\n`;
        if (step.status === 'completed') {
          message += `   _${step.rationale}_\n`;
        }
      });
    }

    if (journey.final_outcome) {
      const outcomeEmoji = journey.final_outcome.success ? '🎉' : '😞';
      message += `\n${outcomeEmoji} **Final Result:** ${journey.final_outcome.message}\n`;
      message += `⏱️ **Total Time:** ${journey.execution_time.toFixed(1)}s\n`;
    }

    return message;
  }
}