#!/usr/bin/env python3
"""
Test IBKR options data extraction capability during off-market hours
Based on the screenshot showing contract IDs and options data
"""

import asyncio
import logging
from datetime import datetime
from backend.services.ibkr_service import ibkr_service

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('IBKROptionsTest')

async def test_options_extraction():
    """Test IBKR options data extraction during off-market hours"""
    
    logger.info("="*50)
    logger.info("IBKR OPTIONS DATA EXTRACTION TEST")
    logger.info("="*50)
    logger.info(f"Test Time: {datetime.now()}")
    logger.info("Testing during off-market hours...")
    
    try:
        # Test 1: Check IBKR connection
        logger.info("\n[TEST 1] Testing IBKR Gateway connection...")
        connected = await ibkr_service.connect()
        
        if not connected:
            logger.error("❌ IBKR Gateway connection FAILED")
            logger.info("\nChecking IBKR Gateway status:")
            logger.info("1. Is IBKR Gateway running?")
            logger.info("2. Is it configured for API connections on port 4001?")
            logger.info("3. Are there any client ID conflicts?")
            return False
        
        logger.info("✅ IBKR Gateway connected successfully!")
        
        # Test 2: Get SPY price
        logger.info("\n[TEST 2] Fetching SPY price...")
        spy_price = await ibkr_service.get_spy_price()
        
        if spy_price and spy_price > 0:
            logger.info(f"✅ SPY Price: ${spy_price:.2f}")
        else:
            logger.warning("⚠️ Could not get live SPY price from IBKR")
            
        # Test 3: Get options chain data
        logger.info("\n[TEST 3] Fetching SPY options chain...")
        logger.info("Requesting options data with contract IDs...")
        
        # Get current trading date
        trading_date = ibkr_service.get_nyse_trading_date()
        expiration = trading_date.strftime('%Y%m%d')
        logger.info(f"Using expiration date: {expiration}")
        
        options_data = await ibkr_service.get_spy_options_chain(expiration_date=expiration)
        
        if "error" in options_data:
            logger.error(f"❌ Options data extraction FAILED: {options_data['error']}")
            logger.info("\nTroubleshooting steps:")
            for step in options_data.get('troubleshooting', []):
                logger.info(f"  - {step}")
            return False
            
        # Test 4: Analyze the results
        logger.info("\n[TEST 4] Analyzing options data...")
        
        contracts = options_data.get('contracts', [])
        if contracts:
            logger.info(f"✅ Successfully retrieved {len(contracts)} option contracts!")
            
            # Show sample contracts
            logger.info("\nSample option contracts:")
            logger.info("-" * 80)
            logger.info(f"{'Symbol':<30} {'Strike':<8} {'Type':<5} {'Bid':<8} {'Ask':<8} {'Last':<8}")
            logger.info("-" * 80)
            
            for i, contract in enumerate(contracts[:10]):  # Show first 10
                logger.info(
                    f"{contract['symbol']:<30} "
                    f"{contract['strike']:<8.2f} "
                    f"{contract['option_type']:<5} "
                    f"{contract['bid']:<8.2f} "
                    f"{contract['ask']:<8.2f} "
                    f"{contract['last']:<8.2f}"
                )
            
            # Check for contract IDs (in the symbol field)
            logger.info(f"\n✅ Contract IDs are embedded in symbols (e.g., {contracts[0]['symbol']})")
            
            # Show AI insights
            ai_insights = options_data.get('ai_insights', {})
            logger.info(f"\nMarket Analysis:")
            logger.info(f"  - Market Regime: {ai_insights.get('market_regime', 'unknown')}")
            logger.info(f"  - VIX Level: {ai_insights.get('vix_level', 0):.2f}")
            logger.info(f"  - Trading Signal: {ai_insights.get('trading_signal', 'neutral')}")
            logger.info(f"  - Confidence: {ai_insights.get('confidence_level', 0):.1%}")
            
            return True
        else:
            logger.warning("⚠️ No option contracts retrieved")
            return False
            
    except Exception as e:
        logger.error(f"❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        # Disconnect from IBKR
        await ibkr_service.disconnect()
        logger.info("\n✅ Disconnected from IBKR Gateway")

async def main():
    """Main test function"""
    logger.info("Starting IBKR options extraction test during off-market hours...")
    
    success = await test_options_extraction()
    
    logger.info("\n" + "="*50)
    if success:
        logger.info("✅ TEST PASSED: IBKR can extract options data during off-market hours!")
        logger.info("✅ Contract IDs are included in the symbol field")
        logger.info("✅ Real-time bid/ask/last prices are available")
    else:
        logger.info("❌ TEST FAILED: Cannot extract options data")
        logger.info("❌ IBKR Gateway connection or configuration issue")
        
    logger.info("="*50)

if __name__ == "__main__":
    asyncio.run(main())