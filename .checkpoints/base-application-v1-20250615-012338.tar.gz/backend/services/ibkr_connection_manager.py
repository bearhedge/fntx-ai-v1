#!/usr/bin/env python3
"""
FNTX.ai IBKR Connection Manager
Comprehensive solution for robust IBKR Gateway/TWS connections with connection pooling,
client ID management, and event loop handling.
"""

import asyncio
import threading
import time
import logging
import os
from typing import Dict, Optional, Any, List, Tuple, Union
from dataclasses import dataclass
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor
from queue import Queue, Empty
import atexit

# Import IBKR libraries
try:
    from ib_insync import IB, Stock, Option, Index, Future, Contract
    from ib_insync.objects import BarDataList, TickData
    # MarketDataTypeEnum might be in different location depending on ib_insync version
    try:
        from ib_insync import MarketDataTypeEnum
    except ImportError:
        # Fallback for older versions
        MarketDataTypeEnum = None
except ImportError:
    print("Warning: ib_insync not installed. Run: pip install ib_insync")

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('IBKRConnectionManager')

@dataclass
class ConnectionConfig:
    """Configuration for IBKR connections"""
    host: str = "127.0.0.1"
    port: int = 4001  # Live account port (7497 for TWS demo)
    client_id: int = 1
    timeout: int = 10
    readonly: bool = False
    account: str = ""
    
@dataclass
class ConnectionStatus:
    """Status of an IBKR connection"""
    client_id: int
    is_connected: bool
    last_used: datetime
    error_count: int
    purpose: str
    thread_id: Optional[str] = None

class IBKRConnectionPool:
    """
    Connection pool manager for IBKR connections with automatic client ID management
    and event loop isolation.
    """
    
    def __init__(self, config: ConnectionConfig, pool_size: int = 5):
        self.config = config
        self.pool_size = pool_size
        self.connections: Dict[int, IB] = {}
        self.connection_status: Dict[int, ConnectionStatus] = {}
        self.available_clients = Queue()
        self.busy_clients: Dict[int, str] = {}  # client_id -> purpose
        self.lock = threading.Lock()
        self.executor = ThreadPoolExecutor(max_workers=pool_size)
        self.shutdown_flag = threading.Event()
        
        # Initialize connection pool
        self._initialize_pool()
        
        # Register cleanup
        atexit.register(self.cleanup)
        
    def _initialize_pool(self):
        """Initialize the connection pool with available client IDs"""
        logger.info(f"Initializing IBKR connection pool with {self.pool_size} connections")
        
        for i in range(self.pool_size):
            client_id = self.config.client_id + i
            self.available_clients.put(client_id)
            
            status = ConnectionStatus(
                client_id=client_id,
                is_connected=False,
                last_used=datetime.now(),
                error_count=0,
                purpose="pool_reserve"
            )
            self.connection_status[client_id] = status
            
        logger.info(f"Connection pool initialized with client IDs: {list(self.connection_status.keys())}")

    def _create_connection_in_thread(self, client_id: int) -> Tuple[bool, Optional[IB], Optional[str]]:
        """Create IBKR connection in a separate thread to avoid event loop conflicts"""
        try:
            # Create new event loop for this thread
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            ib = IB()
            
            # Connect with timeout
            logger.info(f"Connecting client {client_id} to {self.config.host}:{self.config.port}")
            ib.connect(
                host=self.config.host,
                port=self.config.port,
                clientId=client_id,
                timeout=self.config.timeout,
                readonly=self.config.readonly,
                account=self.config.account
            )
            
            if ib.isConnected():
                logger.info(f"Client {client_id} connected successfully")
                return True, ib, None
            else:
                return False, None, "Connection failed"
                
        except Exception as e:
            error_msg = f"Failed to connect client {client_id}: {str(e)}"
            logger.error(error_msg)
            return False, None, error_msg
        finally:
            # Clean up event loop
            try:
                loop.close()
            except:
                pass

    def get_connection(self, purpose: str = "general", timeout: int = 30) -> Optional[IB]:
        """
        Get an available connection from the pool
        
        Args:
            purpose: Description of what the connection will be used for
            timeout: Maximum time to wait for a connection
            
        Returns:
            IB connection object or None if no connection available
        """
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            try:
                # Try to get an available client ID
                client_id = self.available_clients.get(timeout=1)
                
                with self.lock:
                    # Check if connection exists and is valid
                    if client_id in self.connections:
                        ib = self.connections[client_id]
                        if ib.isConnected():
                            # Mark as busy
                            self.busy_clients[client_id] = purpose
                            self.connection_status[client_id].last_used = datetime.now()
                            self.connection_status[client_id].purpose = purpose
                            logger.info(f"Reusing existing connection {client_id} for {purpose}")
                            return ib
                        else:
                            # Connection dead, remove it
                            del self.connections[client_id]
                            logger.warning(f"Removed dead connection {client_id}")
                    
                    # Create new connection in thread
                    future = self.executor.submit(self._create_connection_in_thread, client_id)
                    success, ib, error = future.result(timeout=self.config.timeout)
                    
                    if success and ib:
                        self.connections[client_id] = ib
                        self.busy_clients[client_id] = purpose
                        self.connection_status[client_id].is_connected = True
                        self.connection_status[client_id].last_used = datetime.now()
                        self.connection_status[client_id].purpose = purpose
                        self.connection_status[client_id].error_count = 0
                        return ib
                    else:
                        # Connection failed, put client ID back and try next
                        self.connection_status[client_id].error_count += 1
                        self.available_clients.put(client_id)
                        logger.error(f"Failed to create connection {client_id}: {error}")
                        continue
                        
            except Empty:
                # No available client IDs, wait and retry
                logger.warning("No available client IDs in pool, waiting...")
                time.sleep(1)
                continue
            except Exception as e:
                logger.error(f"Error getting connection: {e}")
                continue
                
        logger.error(f"Failed to get connection within {timeout} seconds")
        return None

    def return_connection(self, ib: IB):
        """Return a connection to the pool"""
        client_id = ib.client.clientId
        
        with self.lock:
            if client_id in self.busy_clients:
                del self.busy_clients[client_id]
                self.available_clients.put(client_id)
                logger.info(f"Returned connection {client_id} to pool")
            else:
                logger.warning(f"Attempted to return unknown connection {client_id}")

    def get_pool_status(self) -> Dict[str, Any]:
        """Get current status of the connection pool"""
        with self.lock:
            return {
                "total_connections": len(self.connections),
                "available_connections": self.available_clients.qsize(),
                "busy_connections": len(self.busy_clients),
                "connection_details": [
                    {
                        "client_id": status.client_id,
                        "is_connected": status.is_connected,
                        "last_used": status.last_used.isoformat(),
                        "error_count": status.error_count,
                        "purpose": status.purpose,
                        "busy": status.client_id in self.busy_clients
                    }
                    for status in self.connection_status.values()
                ]
            }

    def cleanup(self):
        """Clean up all connections"""
        logger.info("Cleaning up IBKR connection pool...")
        self.shutdown_flag.set()
        
        with self.lock:
            for client_id, ib in self.connections.items():
                try:
                    if ib.isConnected():
                        ib.disconnect()
                        logger.info(f"Disconnected client {client_id}")
                except Exception as e:
                    logger.error(f"Error disconnecting client {client_id}: {e}")
            
            self.connections.clear()
            self.busy_clients.clear()
            
        self.executor.shutdown(wait=True)
        logger.info("Connection pool cleanup completed")

class IBKRDataExtractor:
    """
    Robust data extraction service for IBKR with automatic connection management
    """
    
    def __init__(self, connection_pool: IBKRConnectionPool):
        self.pool = connection_pool
        self.logger = logging.getLogger('IBKRDataExtractor')
        
    def get_market_data(self, contract: Contract, data_type: str = "real_time") -> Dict[str, Any]:
        """
        Get market data for a contract with automatic connection handling
        
        Args:
            contract: IBKR contract object
            data_type: Type of data to request ("real_time", "delayed", "frozen")
            
        Returns:
            Dictionary with market data
        """
        ib = self.pool.get_connection(f"market_data_{contract.symbol}")
        if not ib:
            raise ConnectionError("Could not get IBKR connection for market data")
            
        try:
            # Set market data type if enum is available
            if MarketDataTypeEnum:
                if data_type == "delayed":
                    ib.reqMarketDataType(MarketDataTypeEnum.DELAYED)
                elif data_type == "frozen":
                    ib.reqMarketDataType(MarketDataTypeEnum.FROZEN)
                else:
                    ib.reqMarketDataType(MarketDataTypeEnum.REALTIME)
            else:
                # Fallback to numeric values
                if data_type == "delayed":
                    ib.reqMarketDataType(3)  # DELAYED
                elif data_type == "frozen":
                    ib.reqMarketDataType(2)  # FROZEN
                else:
                    ib.reqMarketDataType(1)  # REALTIME
            
            # Qualify the contract
            ib.qualifyContracts(contract)
            
            # Request market data
            ticker = ib.reqMktData(contract, '', False, False)
            ib.sleep(2)  # Wait for data
            
            # Extract data
            data = {
                "symbol": contract.symbol,
                "last_price": float(ticker.last) if ticker.last else 0,
                "bid": float(ticker.bid) if ticker.bid else 0,
                "ask": float(ticker.ask) if ticker.ask else 0,
                "volume": int(ticker.volume) if ticker.volume else 0,
                "high": float(ticker.high) if ticker.high else 0,
                "low": float(ticker.low) if ticker.low else 0,
                "close": float(ticker.close) if ticker.close else 0,
                "timestamp": datetime.now().isoformat(),
                "data_type": data_type
            }
            
            # Cancel market data subscription
            ib.cancelMktData(contract)
            
            return data
            
        except Exception as e:
            self.logger.error(f"Error getting market data for {contract.symbol}: {e}")
            raise
        finally:
            self.pool.return_connection(ib)

    def get_spy_options_chain(self, days_to_expiry: int = 7) -> List[Dict[str, Any]]:
        """
        Get SPY options chain with specified days to expiry
        
        Args:
            days_to_expiry: Maximum days to expiration for options
            
        Returns:
            List of option contracts with market data
        """
        ib = self.pool.get_connection("spy_options_chain")
        if not ib:
            raise ConnectionError("Could not get IBKR connection for options chain")
            
        try:
            # Create SPY stock contract
            spy_stock = Stock('SPY', 'SMART', 'USD')
            ib.qualifyContracts(spy_stock)
            
            # Get SPY current price
            spy_ticker = ib.reqMktData(spy_stock, '', False, False)
            ib.sleep(2)
            spy_price = float(spy_ticker.last) if spy_ticker.last else 0
            ib.cancelMktData(spy_stock)
            
            # Get option chains
            chains = ib.reqSecDefOptParams('SPY', '', 'STK', 8314)
            
            options_data = []
            target_date = datetime.now().date() + timedelta(days=days_to_expiry)
            
            for chain in chains:
                # Filter expirations within target days
                valid_expirations = [
                    exp for exp in chain.expirations 
                    if datetime.strptime(exp, '%Y%m%d').date() <= target_date
                ]
                
                for exp in valid_expirations[:3]:  # Limit to first 3 expirations
                    # Get strikes around current price
                    strikes_near_money = [
                        strike for strike in chain.strikes
                        if abs(strike - spy_price) <= 20  # Within $20 of current price
                    ]
                    
                    for strike in strikes_near_money[:10]:  # Limit to 10 strikes per expiration
                        for right in ['P', 'C']:  # Puts and Calls
                            try:
                                option = Option('SPY', exp, strike, right, 'SMART')
                                ib.qualifyContracts(option)
                                
                                ticker = ib.reqMktData(option, '', False, False)
                                ib.sleep(1)
                                
                                if ticker.last:
                                    options_data.append({
                                        "symbol": f"SPY {exp} {strike}{right}",
                                        "underlying": "SPY",
                                        "expiration": exp,
                                        "strike": strike,
                                        "right": right,
                                        "last_price": float(ticker.last),
                                        "bid": float(ticker.bid) if ticker.bid else 0,
                                        "ask": float(ticker.ask) if ticker.ask else 0,
                                        "volume": int(ticker.volume) if ticker.volume else 0,
                                        "open_interest": getattr(ticker, 'openInterest', 0),
                                        "implied_vol": getattr(ticker, 'impliedVol', 0),
                                        "delta": getattr(ticker, 'delta', 0),
                                        "gamma": getattr(ticker, 'gamma', 0),
                                        "theta": getattr(ticker, 'theta', 0),
                                        "vega": getattr(ticker, 'vega', 0),
                                        "spy_price": spy_price,
                                        "timestamp": datetime.now().isoformat()
                                    })
                                
                                ib.cancelMktData(option)
                                
                            except Exception as e:
                                self.logger.warning(f"Error processing option {strike}{right} {exp}: {e}")
                                continue
            
            self.logger.info(f"Retrieved {len(options_data)} SPY options contracts")
            return options_data
            
        except Exception as e:
            self.logger.error(f"Error getting SPY options chain: {e}")
            raise
        finally:
            self.pool.return_connection(ib)

    def get_extended_hours_data(self, symbol: str = "SPY") -> Dict[str, Any]:
        """
        Get extended hours data using ES futures for after-hours SPY tracking
        
        Args:
            symbol: Symbol to get extended hours data for (defaults to SPY)
            
        Returns:
            Dictionary with extended hours market data
        """
        ib = self.pool.get_connection("extended_hours_data")
        if not ib:
            raise ConnectionError("Could not get IBKR connection for extended hours data")
            
        try:
            # Use ES (E-mini S&P 500) futures for extended hours data
            # ES futures trade nearly 24/5 and closely track SPY
            current_month = datetime.now().strftime('%Y%m')
            
            # Create ES futures contract (quarterly expiration)
            es_contract = Future('ES', '20241220', 'CME')  # Update expiration as needed
            ib.qualifyContracts(es_contract)
            
            # Get ES market data
            es_ticker = ib.reqMktData(es_contract, '', False, False)
            ib.sleep(2)
            
            # Also get regular SPY data for comparison
            spy_stock = Stock('SPY', 'SMART', 'USD')
            ib.qualifyContracts(spy_stock)
            spy_ticker = ib.reqMktData(spy_stock, '', False, False)
            ib.sleep(2)
            
            # Calculate SPY equivalent price from ES
            # ES is typically ~10x SPY price, but this can vary
            es_price = float(es_ticker.last) if es_ticker.last else 0
            spy_equivalent = es_price / 10  # Rough conversion
            
            data = {
                "symbol": symbol,
                "extended_hours": True,
                "es_price": es_price,
                "spy_equivalent_price": spy_equivalent,
                "spy_regular_price": float(spy_ticker.last) if spy_ticker.last else 0,
                "es_bid": float(es_ticker.bid) if es_ticker.bid else 0,
                "es_ask": float(es_ticker.ask) if es_ticker.ask else 0,
                "es_volume": int(es_ticker.volume) if es_ticker.volume else 0,
                "market_hours": self._is_market_hours(),
                "extended_hours_active": self._is_extended_hours(),
                "timestamp": datetime.now().isoformat(),
                "data_source": "ES_futures"
            }
            
            # Clean up
            ib.cancelMktData(es_contract)
            ib.cancelMktData(spy_stock)
            
            return data
            
        except Exception as e:
            self.logger.error(f"Error getting extended hours data: {e}")
            raise
        finally:
            self.pool.return_connection(ib)

    def get_historical_data(self, contract: Contract, duration: str = "1 D", 
                          bar_size: str = "1 min") -> List[Dict[str, Any]]:
        """
        Get historical data for a contract
        
        Args:
            contract: IBKR contract object
            duration: Duration string (e.g., "1 D", "1 W", "1 M")
            bar_size: Bar size string (e.g., "1 min", "5 mins", "1 hour")
            
        Returns:
            List of historical bars
        """
        ib = self.pool.get_connection(f"historical_{contract.symbol}")
        if not ib:
            raise ConnectionError("Could not get IBKR connection for historical data")
            
        try:
            ib.qualifyContracts(contract)
            
            bars = ib.reqHistoricalData(
                contract,
                endDateTime='',
                durationStr=duration,
                barSizeSetting=bar_size,
                whatToShow='TRADES',
                useRTH=False,  # Include extended hours
                formatDate=1
            )
            
            historical_data = []
            for bar in bars:
                historical_data.append({
                    "date": bar.date.isoformat(),
                    "open": float(bar.open),
                    "high": float(bar.high),
                    "low": float(bar.low),
                    "close": float(bar.close),
                    "volume": int(bar.volume),
                    "average": float(bar.average),
                    "bar_count": int(bar.barCount)
                })
            
            return historical_data
            
        except Exception as e:
            self.logger.error(f"Error getting historical data for {contract.symbol}: {e}")
            raise
        finally:
            self.pool.return_connection(ib)

    def _is_market_hours(self) -> bool:
        """Check if market is currently open (9:30 AM - 4:00 PM ET)"""
        now = datetime.now()
        return (now.weekday() < 5 and 
                9 <= now.hour < 16 and
                not (now.hour == 9 and now.minute < 30))

    def _is_extended_hours(self) -> bool:
        """Check if extended hours trading is active"""
        now = datetime.now()
        # Extended hours: 4:00 AM - 9:30 AM and 4:00 PM - 8:00 PM ET
        return (now.weekday() < 5 and 
                ((4 <= now.hour < 9) or 
                 (now.hour == 9 and now.minute < 30) or
                 (16 <= now.hour < 20)))

# Global connection manager instance
_connection_manager = None

def get_connection_manager(config: Optional[ConnectionConfig] = None) -> IBKRConnectionPool:
    """Get the global connection manager instance"""
    global _connection_manager
    
    if _connection_manager is None:
        if config is None:
            config = ConnectionConfig(
                host=os.getenv("IBKR_HOST", "127.0.0.1"),
                port=int(os.getenv("IBKR_PORT", "4001")),
                client_id=int(os.getenv("IBKR_CLIENT_ID", "1")),
                timeout=int(os.getenv("IBKR_TIMEOUT", "10"))
            )
        _connection_manager = IBKRConnectionPool(config)
    
    return _connection_manager

def get_data_extractor() -> IBKRDataExtractor:
    """Get a data extractor instance with the global connection manager"""
    return IBKRDataExtractor(get_connection_manager())

# Example usage and testing
if __name__ == "__main__":
    # Test the connection manager
    config = ConnectionConfig(
        host="127.0.0.1",
        port=4001,  # Change to 7497 for TWS demo
        client_id=1,
        timeout=10
    )
    
    pool = IBKRConnectionPool(config, pool_size=3)
    extractor = IBKRDataExtractor(pool)
    
    try:
        # Test market data
        spy_stock = Stock('SPY', 'SMART', 'USD')
        market_data = extractor.get_market_data(spy_stock)
        print(f"SPY Market Data: {market_data}")
        
        # Test options chain
        options = extractor.get_spy_options_chain(days_to_expiry=3)
        print(f"Retrieved {len(options)} SPY options")
        
        # Test extended hours data
        extended_data = extractor.get_extended_hours_data()
        print(f"Extended Hours Data: {extended_data}")
        
        # Test pool status
        status = pool.get_pool_status()
        print(f"Pool Status: {status}")
        
    except Exception as e:
        print(f"Test failed: {e}")
    finally:
        pool.cleanup()