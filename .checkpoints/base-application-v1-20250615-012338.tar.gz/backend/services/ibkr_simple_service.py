#!/usr/bin/env python3
"""
Simple IBKR Service for API endpoints with robust fallback
Provides reliable SPY data and options chains with enhanced error handling
"""

import os
import logging
import requests
from datetime import datetime
from typing import Dict, List, Optional, Any
from dotenv import load_dotenv

load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('IBKRSimpleService')

class IBKRSimpleService:
    """
    Simplified IBKR service that prioritizes reliability over advanced features
    Uses robust web fallbacks when IBKR is unavailable
    """
    
    def __init__(self):
        self.host = os.getenv("IBKR_HOST", "127.0.0.1")
        self.port = int(os.getenv("IBKR_PORT", "4001"))
        self.client_id = int(os.getenv("IBKR_CLIENT_ID", "1"))  # Use client ID 1 for simple service
        self.ib_connection = None
        self.last_spy_price = 0
        self.connection_available = False
        
        logger.info(f"IBKRSimpleService initialized for {self.host}:{self.port}")

    def _try_ibkr_connection(self) -> bool:
        """Try to establish IBKR connection with short timeout"""
        try:
            from ib_insync import IB, Stock
            
            if self.ib_connection and self.ib_connection.isConnected():
                return True
            
            logger.info("Attempting quick IBKR connection...")
            self.ib_connection = IB()
            self.ib_connection.connect(
                host=self.host,
                port=self.port,
                clientId=self.client_id,
                timeout=3  # Very short timeout
            )
            
            if self.ib_connection.isConnected():
                logger.info("IBKR connection successful")
                self.connection_available = True
                return True
            else:
                self.connection_available = False
                return False
                
        except Exception as e:
            logger.warning(f"IBKR connection failed: {e}")
            self.connection_available = False
            return False

    def get_spy_price(self) -> Dict[str, Any]:
        """Get SPY price with IBKR first, web fallback second"""
        try:
            # Quick IBKR attempt
            if self._try_ibkr_connection():
                spy_data = self._get_spy_from_ibkr()
                if spy_data and spy_data.get('price', 0) > 0:
                    self.last_spy_price = spy_data['price']
                    return spy_data
            
            # Web fallback
            logger.info("Using web fallback for SPY price")
            web_data = self._get_spy_from_web()
            if web_data and web_data.get('price', 0) > 0:
                self.last_spy_price = web_data['price']
                return web_data
            
            # Last resort: return cached price
            if self.last_spy_price > 0:
                return {
                    "price": self.last_spy_price,
                    "change": 0,
                    "volume": 0,
                    "timestamp": datetime.now().isoformat(),
                    "source": "cached"
                }
            
            # Emergency fallback
            return {
                "price": 602.66,  # Current approximate SPY price
                "change": 0,
                "volume": 0,
                "timestamp": datetime.now().isoformat(),
                "source": "emergency_fallback"
            }
            
        except Exception as e:
            logger.error(f"Error getting SPY price: {e}")
            return {
                "price": 602.66,  # Emergency price
                "change": 0,
                "volume": 0,
                "timestamp": datetime.now().isoformat(),
                "source": "error_fallback",
                "error": str(e)
            }

    def _get_spy_from_ibkr(self) -> Optional[Dict[str, Any]]:
        """Get SPY from IBKR with quick timeout"""
        try:
            from ib_insync import Stock
            
            if not self.ib_connection or not self.ib_connection.isConnected():
                return None
            
            spy_contract = Stock('SPY', 'SMART', 'USD')
            self.ib_connection.qualifyContracts(spy_contract)
            
            ticker = self.ib_connection.reqMktData(spy_contract, '', False, False)
            self.ib_connection.sleep(2)  # Short wait
            
            if ticker.last and ticker.last > 0:
                prev_close = ticker.close if ticker.close else ticker.last
                return {
                    "price": float(ticker.last),
                    "change": float(ticker.last - prev_close),
                    "volume": int(ticker.volume) if ticker.volume else 0,
                    "high": float(ticker.high) if ticker.high else float(ticker.last),
                    "low": float(ticker.low) if ticker.low else float(ticker.last),
                    "bid": float(ticker.bid) if ticker.bid else 0,
                    "ask": float(ticker.ask) if ticker.ask else 0,
                    "timestamp": datetime.now().isoformat(),
                    "source": "ibkr_live"
                }
            
            return None
            
        except Exception as e:
            logger.warning(f"IBKR SPY data failed: {e}")
            return None

    def _get_spy_from_web(self) -> Optional[Dict[str, Any]]:
        """Get SPY from web sources"""
        try:
            # Yahoo Finance
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            response = requests.get(
                "https://query1.finance.yahoo.com/v8/finance/chart/SPY",
                headers=headers,
                timeout=5
            )
            
            if response.status_code == 200:
                data = response.json()
                current_price = data['chart']['result'][0]['meta']['regularMarketPrice']
                
                return {
                    "price": float(current_price),
                    "change": 0,
                    "volume": 0,
                    "timestamp": datetime.now().isoformat(),
                    "source": "yahoo_finance"
                }
        except Exception as e:
            logger.warning(f"Yahoo Finance failed: {e}")
        
        return None

    def get_spy_options_chain(self, max_dte: int = 7, option_type: str = "both") -> List[Dict[str, Any]]:
        """Get options chain with IBKR or return empty list with error message"""
        try:
            if self._try_ibkr_connection():
                options = self._get_options_from_ibkr(max_dte, option_type)
                if options:
                    return options
            
            # Return empty list with status message
            logger.warning("Options chain not available - IBKR connection required")
            return []
            
        except Exception as e:
            logger.error(f"Options chain error: {e}")
            return []

    def _get_options_from_ibkr(self, max_dte: int, option_type: str) -> List[Dict[str, Any]]:
        """Get options from IBKR using efficient off-hours method"""
        try:
            from ib_insync import Stock, Option
            
            if not self.ib_connection or not self.ib_connection.isConnected():
                return []
            
            # Get SPY contract
            spy_contract = Stock('SPY', 'SMART', 'USD')
            self.ib_connection.qualifyContracts(spy_contract)
            
            # Get SPY price for strike calculations
            spy_price = self.last_spy_price or 600.0  # Use cached or fallback
            
            # Use efficient method: reqSecDefOptParams (works 24/7)
            logger.info("Using reqSecDefOptParams for options chain (works off-hours)")
            params = self.ib_connection.reqSecDefOptParams('SPY', '', 'STK', spy_contract.conId)
            
            if not params:
                logger.warning("No option parameters available")
                return []
            
            param = params[0]  # Usually only one
            
            # Get nearby expirations (limit to 3)
            expirations = sorted(param.expirations)[:3]
            
            # Filter strikes around current price (±$30 range)
            all_strikes = sorted(param.strikes)
            spy_price_approx = spy_price or 600.0
            nearby_strikes = [s for s in all_strikes 
                             if abs(s - spy_price_approx) <= 30][:10]  # Max 10 strikes
            
            options_data = []
            
            # Build contracts efficiently
            contracts = []
            for exp in expirations:
                for strike in nearby_strikes:
                    # Filter by option type
                    rights = []
                    if option_type == "put":
                        rights = ['P']
                    elif option_type == "call":
                        rights = ['C']
                    else:
                        rights = ['P', 'C']
                    
                    for right in rights:
                        contracts.append(Option('SPY', exp, strike, right, 'SMART'))
                        if len(contracts) >= 30:  # Limit total contracts
                            break
                    if len(contracts) >= 30:
                        break
                if len(contracts) >= 30:
                    break
            
            # Get contract details (works off-hours)
            logger.info(f"Getting contract details for {len(contracts)} contracts...")
            for contract in contracts:
                try:
                    # Qualify each contract
                    self.ib_connection.qualifyContracts(contract)
                    
                    # Calculate basic info without requiring live market data
                    dte = (datetime.strptime(contract.lastTradeDateOrContractMonth, '%Y%m%d').date() - 
                          datetime.now().date()).days
                    
                    # Estimate pricing (since market data may not be available)
                    intrinsic_value = max(0, 
                        (spy_price_approx - contract.strike) if contract.right == 'P' 
                        else (contract.strike - spy_price_approx))
                    
                    time_value = max(0.01, 0.20 * (dte / 30) if dte > 0 else 0.01)
                    estimated_price = intrinsic_value + time_value
                    
                    options_data.append({
                        "contract_symbol": f"SPY_{contract.lastTradeDateOrContractMonth}_{contract.strike}_{contract.right}",
                        "underlying": "SPY",
                        "expiration": contract.lastTradeDateOrContractMonth,
                        "strike": float(contract.strike),
                        "right": contract.right,
                        "dte": dte,
                        "last": estimated_price,  # Estimated when market closed
                        "bid": estimated_price * 0.98,  # Estimate bid/ask spread
                        "ask": estimated_price * 1.02,
                        "volume": 0,  # Not available off-hours
                        "open_interest": 1000,  # Typical for SPY
                        "implied_volatility": 0.20,  # Default estimate
                        "delta": -0.5 if contract.right == 'P' else 0.5,  # Simplified
                        "gamma": 0.02,
                        "theta": -0.05,
                        "vega": 0.08,
                        "underlying_price": spy_price_approx,
                        "timestamp": datetime.now().isoformat(),
                        "ai_score": self._calculate_ai_score(estimated_price, contract.strike, spy_price_approx, contract.right, dte),
                        "data_source": "contract_metadata"  # Indicate this is metadata-based
                    })
                    
                    if len(options_data) >= 20:
                        break
                        
                except Exception as e:
                    logger.warning(f"Error processing contract {contract.localSymbol}: {e}")
                    continue
            
            logger.info(f"Retrieved {len(options_data)} options contracts using metadata")
            return sorted(options_data, key=lambda x: (x['dte'], abs(x['strike'] - spy_price_approx)))
            
        except Exception as e:
            logger.error(f"Error getting options from IBKR: {e}")
            return []

    def _calculate_ai_score(self, option_price: float, strike: float, spy_price: float, 
                          option_type: str, dte: int) -> float:
        """Simple AI score calculation"""
        try:
            # Distance from money
            if option_type == 'P':
                moneyness = (spy_price - strike) / spy_price
            else:
                moneyness = (strike - spy_price) / spy_price
            
            distance_score = 10 - abs(moneyness * 100)
            time_score = max(1, 10 - dte) if dte <= 30 else 1
            liquidity_score = min(10, option_price * 20) if option_price > 0 else 1
            type_score = 8 if option_type == 'P' else 6
            
            ai_score = (distance_score * 0.3 + time_score * 0.3 + 
                       liquidity_score * 0.2 + type_score * 0.2)
            
            return round(max(1, min(10, ai_score)), 1)
        except:
            return 5.0

    def get_market_insights(self) -> Dict[str, Any]:
        """Get market insights with connection status"""
        try:
            spy_data = self.get_spy_price()
            spy_price = spy_data.get('price', 0)
            
            return {
                "timestamp": datetime.now().isoformat(),
                "spy_data": spy_data,
                "market_status": "extended_hours" if not self._is_market_hours() else "open",
                "connection_status": {
                    "status": "healthy" if self.connection_available else "degraded",
                    "ibkr_available": self.connection_available,
                    "fallback_active": not self.connection_available
                },
                "market_regime": {
                    "regime": "favorable_for_selling" if spy_price > 600 else "neutral",
                    "vix_estimate": 15.0,
                    "confidence": 0.7 if self.connection_available else 0.4
                },
                "total_options_available": 20 if self.connection_available else 0
            }
            
        except Exception as e:
            logger.error(f"Error getting market insights: {e}")
            return {
                "timestamp": datetime.now().isoformat(),
                "error": str(e),
                "market_status": "error"
            }

    def _is_market_hours(self) -> bool:
        """Check if market is open"""
        now = datetime.now()
        return (now.weekday() < 5 and 9 <= now.hour < 16 and
                not (now.hour == 9 and now.minute < 30))

    def cleanup(self):
        """Clean up connection"""
        try:
            if self.ib_connection and self.ib_connection.isConnected():
                self.ib_connection.disconnect()
                self.ib_connection = None
        except Exception as e:
            logger.error(f"Cleanup error: {e}")

# Global simple service instance
simple_ibkr_service = IBKRSimpleService()