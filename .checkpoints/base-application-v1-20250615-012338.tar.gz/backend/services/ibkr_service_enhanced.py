#!/usr/bin/env python3
"""
FNTX.ai Enhanced IBKR Service - Interactive Brokers API Integration
Enhanced with robust connection management and comprehensive data extraction
Uses the new IBKRConnectionManager for foolproof connections
"""

import os
import json
import time
import asyncio
import logging
import requests
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dotenv import load_dotenv

# Import the new connection manager
from .ibkr_connection_manager import (
    get_connection_manager, 
    get_data_extractor, 
    ConnectionConfig,
    IBKRDataExtractor
)

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('IBKRServiceEnhanced')

class IBKRServiceEnhanced:
    """
    Enhanced IBKR Service with robust connection management and comprehensive data extraction.
    Replaces the old service with connection pool management and extended hours support.
    """
    
    def __init__(self):
        self.host = os.getenv("IBKR_HOST", "127.0.0.1")
        self.port = int(os.getenv("IBKR_PORT", "4001"))  # Live account
        self.client_id = int(os.getenv("IBKR_CLIENT_ID", "1"))
        
        # Initialize connection manager with robust configuration
        config = ConnectionConfig(
            host=self.host,
            port=self.port,
            client_id=self.client_id,
            timeout=15,
            readonly=False
        )
        self.connection_manager = get_connection_manager(config)
        self.data_extractor = get_data_extractor()
        
        # Last known prices for fallback
        self.last_known_spy_price = 0
        self.last_spy_update = None
        
        logger.info(f"IBKRServiceEnhanced initialized with connection manager for {self.host}:{self.port}")

    def get_connection_status(self) -> Dict[str, Any]:
        """Get detailed status of all connections in the pool"""
        try:
            status = self.connection_manager.get_pool_status()
            return {
                "status": "healthy" if status['available_connections'] > 0 else "degraded",
                "total_connections": status['total_connections'],
                "available_connections": status['available_connections'],
                "busy_connections": status['busy_connections'],
                "connection_details": status['connection_details'],
                "last_check": datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"Error getting connection status: {e}")
            return {
                "status": "error",
                "error": str(e),
                "last_check": datetime.now().isoformat()
            }

    def get_spy_price(self) -> Dict[str, Any]:
        """
        Get current SPY price using the robust connection manager
        Includes fallback to web sources if IBKR fails
        """
        try:
            # Try IBKR with connection manager first
            spy_data = self._get_spy_from_ibkr()
            if spy_data and spy_data.get('price', 0) > 0:
                self.last_known_spy_price = spy_data['price']
                self.last_spy_update = datetime.now()
                logger.info(f"SPY price from IBKR: ${spy_data['price']:.2f}")
                return spy_data
            
            # Fallback to web sources
            logger.warning("IBKR failed, trying web fallback")
            web_data = self._get_spy_from_web_fallback()
            if web_data and web_data.get('price', 0) > 0:
                self.last_known_spy_price = web_data['price']
                self.last_spy_update = datetime.now()
                return web_data
            
            # Last resort: use cached price
            if self.last_known_spy_price > 0:
                logger.warning(f"Using cached SPY price: ${self.last_known_spy_price:.2f}")
                return {
                    "price": self.last_known_spy_price,
                    "change": 0,
                    "volume": 0,
                    "timestamp": datetime.now().isoformat(),
                    "source": "cached",
                    "last_update": self.last_spy_update.isoformat() if self.last_spy_update else None
                }
            
            raise Exception("No SPY price available from any source")
            
        except Exception as e:
            logger.error(f"Error getting SPY price: {e}")
            return {
                "price": 0,
                "change": 0,
                "volume": 0,
                "timestamp": datetime.now().isoformat(),
                "source": "error",
                "error": str(e)
            }
    
    def _get_spy_from_ibkr(self) -> Optional[Dict[str, Any]]:
        """Get SPY data using the new connection manager"""
        try:
            from ib_insync import Stock
            
            # Create SPY contract
            spy_contract = Stock('SPY', 'SMART', 'USD')
            
            # Use data extractor for robust connection handling
            data = self.data_extractor.get_market_data(spy_contract, "real_time")
            
            if data and data.get('last_price', 0) > 0:
                return {
                    "price": data['last_price'],
                    "change": data['last_price'] - data['close'] if data['close'] else 0,
                    "volume": data['volume'],
                    "high": data['high'],
                    "low": data['low'],
                    "bid": data['bid'],
                    "ask": data['ask'],
                    "timestamp": data['timestamp'],
                    "source": "ibkr_live",
                    "data_type": data['data_type']
                }
            else:
                logger.warning("No valid SPY price from IBKR connection manager")
                return None
                
        except Exception as e:
            logger.error(f"Error getting SPY from IBKR connection manager: {e}")
            return None

    def _get_spy_from_web_fallback(self) -> Optional[Dict[str, Any]]:
        """Get SPY price from web sources as fallback"""
        try:
            # Try Yahoo Finance first
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            response = requests.get(
                "https://query1.finance.yahoo.com/v8/finance/chart/SPY",
                headers=headers,
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                current_price = data['chart']['result'][0]['meta']['regularMarketPrice']
                
                return {
                    "price": float(current_price),
                    "change": 0,  # Not available from this endpoint
                    "volume": 0,
                    "timestamp": datetime.now().isoformat(),
                    "source": "yahoo_finance"
                }
        except Exception as e:
            logger.warning(f"Yahoo Finance fallback failed: {e}")
        
        return None

    def get_spy_options_chain(self, max_dte: int = 7, option_type: str = "both") -> List[Dict[str, Any]]:
        """
        Get SPY options chain using the robust connection manager
        
        Args:
            max_dte: Maximum days to expiration
            option_type: "put", "call", or "both"
        """
        try:
            # Get options data using connection manager
            options_data = self.data_extractor.get_spy_options_chain(days_to_expiry=max_dte)
            
            # Filter by option type if specified
            if option_type.lower() == "put":
                options_data = [opt for opt in options_data if opt['right'] == 'P']
            elif option_type.lower() == "call":
                options_data = [opt for opt in options_data if opt['right'] == 'C']
            
            # Convert to expected format and add AI scores
            formatted_options = []
            for opt in options_data:
                dte = (datetime.strptime(opt['expiration'], '%Y%m%d').date() - datetime.now().date()).days
                
                formatted_opt = {
                    "symbol": opt['symbol'],
                    "contract_symbol": f"SPY_{opt['expiration']}_{opt['strike']}_{opt['right']}",
                    "underlying": opt['underlying'],
                    "expiration": opt['expiration'],
                    "strike": opt['strike'],
                    "right": opt['right'],
                    "dte": dte,
                    "last": opt['last_price'],
                    "bid": opt['bid'],
                    "ask": opt['ask'],
                    "volume": opt['volume'],
                    "open_interest": opt['open_interest'],
                    "implied_volatility": opt['implied_vol'],
                    "delta": opt['delta'],
                    "gamma": opt['gamma'],
                    "theta": opt['theta'],
                    "vega": opt['vega'],
                    "underlying_price": opt['spy_price'],
                    "timestamp": opt['timestamp'],
                    "ai_score": self._calculate_ai_score(
                        opt['last_price'], opt['strike'], opt['spy_price'], opt['right'], dte
                    )
                }
                formatted_options.append(formatted_opt)
            
            logger.info(f"Retrieved {len(formatted_options)} SPY options contracts")
            return sorted(formatted_options, key=lambda x: (x['dte'], abs(x['strike'] - x['underlying_price'])))
            
        except Exception as e:
            logger.error(f"Error getting SPY options chain: {e}")
            return []

    def get_extended_hours_data(self) -> Dict[str, Any]:
        """Get extended hours market data using ES futures"""
        try:
            # Use data extractor for extended hours data
            extended_data = self.data_extractor.get_extended_hours_data("SPY")
            
            # Add market status information
            extended_data['market_status'] = self._get_market_status()
            extended_data['can_trade_options'] = self._can_trade_options()
            
            return extended_data
            
        except Exception as e:
            logger.error(f"Error getting extended hours data: {e}")
            return {
                "extended_hours": True,
                "market_status": "error",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }

    def get_historical_data(self, symbol: str = "SPY", duration: str = "1 D", 
                          bar_size: str = "1 min") -> List[Dict[str, Any]]:
        """Get historical data for analysis"""
        try:
            from ib_insync import Stock
            
            # Create contract
            if symbol == "SPY":
                contract = Stock('SPY', 'SMART', 'USD')
            else:
                contract = Stock(symbol, 'SMART', 'USD')
            
            # Get historical data using connection manager
            historical_data = self.data_extractor.get_historical_data(contract, duration, bar_size)
            
            logger.info(f"Retrieved {len(historical_data)} historical bars for {symbol}")
            return historical_data
            
        except Exception as e:
            logger.error(f"Error getting historical data for {symbol}: {e}")
            return []

    def get_market_insights(self) -> Dict[str, Any]:
        """Get comprehensive market insights including SPY, VIX, and options data"""
        try:
            insights = {
                "timestamp": datetime.now().isoformat(),
                "market_status": self._get_market_status(),
                "connection_status": self.get_connection_status(),
            }
            
            # Get SPY data
            spy_data = self.get_spy_price()
            insights["spy_data"] = spy_data
            
            # Get extended hours data if applicable
            if not self._is_market_hours():
                extended_data = self.get_extended_hours_data()
                insights["extended_hours_data"] = extended_data
            
            # Get options chain sample (next 3 days)
            options_sample = self.get_spy_options_chain(max_dte=3)
            insights["options_sample"] = options_sample[:10]  # First 10 contracts
            insights["total_options_available"] = len(options_sample)
            
            # Calculate market regime
            insights["market_regime"] = self._calculate_market_regime(spy_data, options_sample)
            
            return insights
            
        except Exception as e:
            logger.error(f"Error getting market insights: {e}")
            return {
                "timestamp": datetime.now().isoformat(),
                "error": str(e),
                "market_status": "error"
            }

    def _calculate_ai_score(self, option_price: float, strike: float, spy_price: float, 
                          option_type: str, dte: int) -> float:
        """Calculate AI score for option contracts"""
        try:
            # Distance from money factor
            if option_type == 'P':
                moneyness = (spy_price - strike) / spy_price
            else:  # Call
                moneyness = (strike - spy_price) / spy_price
            
            # Prefer slightly OTM options
            distance_score = 10 - abs(moneyness * 100)  # Peak at ATM, decrease with distance
            
            # Time decay factor (prefer shorter time for selling)
            time_score = max(1, 10 - dte) if dte <= 30 else 1
            
            # Liquidity factor (based on option price)
            liquidity_score = min(10, option_price * 20) if option_price > 0 else 1
            
            # Option type preference (currently favor puts)
            type_score = 8 if option_type == 'P' else 6
            
            # Combine scores
            ai_score = (distance_score * 0.3 + time_score * 0.3 + 
                       liquidity_score * 0.2 + type_score * 0.2)
            
            return round(max(1, min(10, ai_score)), 1)
            
        except Exception:
            return 5.0  # Default score

    def _get_market_status(self) -> str:
        """Get current market status"""
        now = datetime.now()
        
        if self._is_market_hours():
            return "open"
        elif self._is_extended_hours():
            return "extended_hours"
        elif now.weekday() >= 5:  # Weekend
            return "weekend"
        else:
            return "closed"

    def _is_market_hours(self) -> bool:
        """Check if market is currently open (9:30 AM - 4:00 PM ET)"""
        now = datetime.now()
        return (now.weekday() < 5 and 
                9 <= now.hour < 16 and
                not (now.hour == 9 and now.minute < 30))

    def _is_extended_hours(self) -> bool:
        """Check if extended hours trading is active"""
        now = datetime.now()
        # Extended hours: 4:00 AM - 9:30 AM and 4:00 PM - 8:00 PM ET
        return (now.weekday() < 5 and 
                ((4 <= now.hour < 9) or 
                 (now.hour == 9 and now.minute < 30) or
                 (16 <= now.hour < 20)))

    def _can_trade_options(self) -> bool:
        """Check if options trading is available"""
        # Options trade during regular market hours only
        return self._is_market_hours()

    def _calculate_market_regime(self, spy_data: Dict[str, Any], 
                               options_data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate current market regime based on price action and options data"""
        try:
            spy_price = spy_data.get('price', 0)
            spy_change = spy_data.get('change', 0)
            
            # Calculate average implied volatility
            if options_data:
                avg_iv = sum(opt.get('implied_volatility', 0.2) for opt in options_data) / len(options_data)
                vix_estimate = avg_iv * 100
            else:
                vix_estimate = 20  # Default
            
            # Determine regime
            if vix_estimate < 15 and spy_change > 0:
                regime = "favorable_for_selling"
                confidence = 0.8
            elif vix_estimate > 25:
                regime = "high_volatility"
                confidence = 0.9
            elif abs(spy_change) > 2:
                regime = "trending"
                confidence = 0.7
            else:
                regime = "neutral"
                confidence = 0.6
            
            return {
                "regime": regime,
                "vix_estimate": vix_estimate,
                "spy_change_percent": (spy_change / spy_price * 100) if spy_price > 0 else 0,
                "confidence": confidence,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error calculating market regime: {e}")
            return {
                "regime": "unknown",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }

    def cleanup(self):
        """Clean up connection manager"""
        try:
            logger.info("Cleaning up IBKR connection manager")
            self.connection_manager.cleanup()
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")

# Global enhanced service instance
enhanced_ibkr_service = IBKRServiceEnhanced()

# Backwards compatibility
def get_ibkr_service() -> IBKRServiceEnhanced:
    """Get the enhanced IBKR service instance"""
    return enhanced_ibkr_service

# Test function for connection verification
def test_connection() -> Dict[str, Any]:
    """Test IBKR connection and return status"""
    try:
        service = get_ibkr_service()
        status = service.get_connection_status()
        
        if status['status'] == 'healthy':
            # Test actual data retrieval
            spy_data = service.get_spy_price()
            if spy_data.get('price', 0) > 0:
                return {
                    "status": "success",
                    "message": "IBKR connection and data retrieval working",
                    "spy_price": spy_data['price'],
                    "data_source": spy_data['source'],
                    "connection_details": status
                }
        
        return {
            "status": "partial",
            "message": "Connection pool available but data retrieval failed",
            "connection_details": status
        }
        
    except Exception as e:
        return {
            "status": "failed",
            "message": f"IBKR connection test failed: {str(e)}"
        }

if __name__ == "__main__":
    # Run connection test
    result = test_connection()
    print(f"Connection test result: {json.dumps(result, indent=2)}")