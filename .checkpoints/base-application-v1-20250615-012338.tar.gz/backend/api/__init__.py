# FNTX.ai API Package
"""
FastAPI application and route handlers for FNTX.ai trading system.
"""