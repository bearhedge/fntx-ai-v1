# FNTX.ai Authentication Package
"""
Authentication utilities for FNTX.ai
"""