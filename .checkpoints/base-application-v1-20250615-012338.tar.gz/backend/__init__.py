# FNTX.ai Backend Package
"""
FNTX.ai Autonomous Options Trading System
Backend package containing all server-side logic, AI agents, and services.
"""

__version__ = "1.0.0-alpha"
__author__ = "FNTX.ai Team"