# FNTX.ai Utilities Package
"""
Shared utilities, configuration, and helper functions.
"""