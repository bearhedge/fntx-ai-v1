#!/usr/bin/env python3
"""
Comprehensive sanity check for SPY options RL training setup
"""
import os
import sys
import psycopg2
from datetime import datetime
import numpy as np
import torch

# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from config import DB_CONFIG, TRADING_CONFIG, RL_CONFIG
from data.data_loader import OptionsDataLoader
from environments.trading_env import SPYOptionsTradingEnv
from agents.rewards import OptionsEpisodeReward

def check_database_connectivity():
    """Check if we can connect to the database"""
    print("\n1. CHECKING DATABASE CONNECTIVITY")
    print("=" * 50)
    
    # Update database name to options_data
    db_config = DB_CONFIG.copy()
    db_config['database'] = 'options_data'
    
    try:
        print(f"Attempting to connect to database: {db_config['database']}")
        print(f"Host: {db_config['host']}, Port: {db_config['port']}, User: {db_config['user']}")
        
        conn = psycopg2.connect(**db_config)
        cursor = conn.cursor()
        
        # Check if connection is successful
        cursor.execute("SELECT version();")
        version = cursor.fetchone()
        print(f"✓ Successfully connected to PostgreSQL")
        print(f"  Database version: {version[0][:50]}...")
        
        # Check tables
        cursor.execute("""
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public' 
            ORDER BY table_name;
        """)
        tables = cursor.fetchall()
        print(f"\n  Available tables:")
        for table in tables:
            print(f"    - {table[0]}")
        
        cursor.close()
        conn.close()
        return True, db_config
        
    except Exception as e:
        print(f"✗ Database connection failed: {str(e)}")
        return False, None

def check_data_availability(db_config):
    """Check how many trading days we have in the database"""
    print("\n2. CHECKING DATA AVAILABILITY")
    print("=" * 50)
    
    if not db_config:
        print("✗ Skipping data check due to database connection failure")
        return False
    
    try:
        conn = psycopg2.connect(**db_config)
        cursor = conn.cursor()
        
        # Check SPY options data
        cursor.execute("""
            SELECT 
                MIN(trade_date) as min_date,
                MAX(trade_date) as max_date,
                COUNT(DISTINCT trade_date) as num_days,
                COUNT(*) as total_records
            FROM spy_options_data
            WHERE symbol = 'SPY';
        """)
        
        result = cursor.fetchone()
        if result and result[0]:
            print(f"✓ SPY options data found:")
            print(f"  Date range: {result[0]} to {result[1]}")
            print(f"  Number of trading days: {result[2]:,}")
            print(f"  Total records: {result[3]:,}")
            
            # Check data for training period
            cursor.execute("""
                SELECT COUNT(DISTINCT trade_date) as train_days
                FROM spy_options_data
                WHERE symbol = 'SPY'
                AND trade_date >= %s
                AND trade_date <= %s;
            """, (RL_CONFIG['train_start_date'], RL_CONFIG['train_end_date']))
            
            train_days = cursor.fetchone()[0]
            print(f"\n  Training period ({RL_CONFIG['train_start_date']} to {RL_CONFIG['train_end_date']}):")
            print(f"  Available days: {train_days}")
            
        else:
            print("✗ No SPY options data found in database")
            return False
            
        cursor.close()
        conn.close()
        return True
        
    except Exception as e:
        print(f"✗ Data availability check failed: {str(e)}")
        return False

def check_environment_initialization(db_config):
    """Check if we can initialize and run the environment"""
    print("\n3. CHECKING ENVIRONMENT INITIALIZATION")
    print("=" * 50)
    
    if not db_config:
        print("✗ Skipping environment check due to database connection failure")
        return False
    
    try:
        # Initialize data loader with corrected database
        print("  Initializing data loader...")
        data_loader = OptionsDataLoader(
            db_config=db_config,
            start_date=RL_CONFIG['train_start_date'],
            end_date=RL_CONFIG['train_end_date']
        )
        
        # Get a sample of data
        sample_data = data_loader.get_options_data(limit=10)
        print(f"✓ Data loader initialized successfully")
        print(f"  Sample data shape: {sample_data.shape if sample_data is not None else 'None'}")
        
        # Initialize environment
        print("\n  Initializing trading environment...")
        env = SPYOptionsTradingEnv(
            data_loader=data_loader,
            initial_capital=10000,
            risk_level='MEDIUM'
        )
        
        print("✓ Environment initialized successfully")
        
        # Try to reset and take a few steps
        print("\n  Testing environment steps...")
        obs = env.reset()
        print(f"  Initial observation shape: {obs.shape}")
        print(f"  Observation sample: {obs[:5]}")
        
        # Take a few random actions
        total_reward = 0
        for i in range(5):
            action = env.action_space.sample()
            obs, reward, done, info = env.step(action)
            total_reward += reward
            print(f"  Step {i+1}: action={action}, reward={reward:.2f}, done={done}")
            if done:
                break
        
        print(f"\n✓ Environment test completed")
        print(f"  Total reward from 5 steps: {total_reward:.2f}")
        return True
        
    except Exception as e:
        print(f"✗ Environment initialization failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def check_reward_calculation():
    """Check if OptionsEpisodeReward is properly imported and working"""
    print("\n4. CHECKING REWARD CALCULATION")
    print("=" * 50)
    
    try:
        print("  Testing OptionsEpisodeReward import and functionality...")
        
        # Create a dummy episode log
        episode_log = {
            'total_return': 1500.0,
            'num_trades': 10,
            'win_rate': 0.6,
            'avg_return_per_trade': 150.0,
            'sharpe_ratio': 1.5,
            'max_drawdown': -0.05,
            'total_commission': 13.0
        }
        
        # Calculate reward
        reward = OptionsEpisodeReward.calculate(episode_log)
        print(f"✓ OptionsEpisodeReward calculation successful")
        print(f"  Sample episode metrics:")
        for key, value in episode_log.items():
            print(f"    {key}: {value}")
        print(f"  Calculated reward: {reward:.4f}")
        
        return True
        
    except Exception as e:
        print(f"✗ Reward calculation check failed: {str(e)}")
        return False

def check_configuration():
    """Check if all configuration values are reasonable"""
    print("\n5. CHECKING CONFIGURATION")
    print("=" * 50)
    
    issues = []
    
    # Check database config
    if DB_CONFIG['database'] != 'options_data':
        issues.append("Database name should be 'options_data', not 'fntx_trading'")
    
    # Check date ranges
    train_start = datetime.strptime(RL_CONFIG['train_start_date'], '%Y-%m-%d')
    train_end = datetime.strptime(RL_CONFIG['train_end_date'], '%Y-%m-%d')
    val_start = datetime.strptime(RL_CONFIG['validation_start_date'], '%Y-%m-%d')
    
    if train_end >= val_start:
        issues.append("Training end date should be before validation start date")
    
    # Check trading config
    if TRADING_CONFIG['commission_per_contract'] <= 0:
        issues.append("Commission per contract should be positive")
    
    if issues:
        print("✗ Configuration issues found:")
        for issue in issues:
            print(f"  - {issue}")
    else:
        print("✓ Configuration looks reasonable")
    
    print("\n  Current configuration:")
    print(f"  Symbol: {TRADING_CONFIG['symbol']}")
    print(f"  Commission: ${TRADING_CONFIG['commission_per_contract']} per contract")
    print(f"  Training period: {RL_CONFIG['train_start_date']} to {RL_CONFIG['train_end_date']}")
    
    return len(issues) == 0

def check_gpu_availability():
    """Check if CUDA/GPU is available"""
    print("\n6. CHECKING GPU AVAILABILITY")
    print("=" * 50)
    
    if torch.cuda.is_available():
        print(f"✓ CUDA is available")
        print(f"  Device count: {torch.cuda.device_count()}")
        print(f"  Current device: {torch.cuda.current_device()}")
        print(f"  Device name: {torch.cuda.get_device_name(0)}")
        print(f"  Memory allocated: {torch.cuda.memory_allocated(0) / 1024**2:.2f} MB")
        print(f"  Memory reserved: {torch.cuda.memory_reserved(0) / 1024**2:.2f} MB")
    else:
        print("✗ CUDA is not available - will use CPU for training")
        print("  This will significantly increase training time")
    
    return torch.cuda.is_available()

def estimate_training_time(db_config):
    """Estimate training time based on data size"""
    print("\n7. ESTIMATING TRAINING TIME")
    print("=" * 50)
    
    if not db_config:
        print("✗ Cannot estimate training time without database connection")
        return
    
    try:
        conn = psycopg2.connect(**db_config)
        cursor = conn.cursor()
        
        # Get number of training days
        cursor.execute("""
            SELECT COUNT(DISTINCT trade_date) as train_days
            FROM spy_options_data
            WHERE symbol = 'SPY'
            AND trade_date >= %s
            AND trade_date <= %s;
        """, (RL_CONFIG['train_start_date'], RL_CONFIG['train_end_date']))
        
        train_days = cursor.fetchone()[0]
        
        # Rough estimates
        episodes_per_epoch = 10
        total_timesteps = 1_000_000  # From PPO config
        steps_per_episode = train_days * 20  # Assuming ~20 decisions per day
        total_episodes = total_timesteps / steps_per_episode
        
        # Time estimates (very rough)
        if torch.cuda.is_available():
            time_per_episode = 2  # seconds with GPU
        else:
            time_per_episode = 10  # seconds with CPU
        
        total_time_seconds = total_episodes * time_per_episode
        total_time_hours = total_time_seconds / 3600
        
        print(f"  Training data: {train_days} days")
        print(f"  Estimated episodes: {int(total_episodes):,}")
        print(f"  Total timesteps: {total_timesteps:,}")
        print(f"\n  Estimated training time:")
        print(f"    With GPU: ~{total_time_hours:.1f} hours")
        print(f"    With CPU: ~{total_time_hours * 5:.1f} hours")
        print(f"\n  Note: These are rough estimates. Actual time may vary significantly.")
        
        cursor.close()
        conn.close()
        
    except Exception as e:
        print(f"✗ Training time estimation failed: {str(e)}")

def main():
    """Run all sanity checks"""
    print("SPY OPTIONS RL TRAINING SANITY CHECK")
    print("=" * 70)
    print(f"Timestamp: {datetime.now()}")
    print(f"Working directory: {os.getcwd()}")
    
    # Run checks
    db_ok, db_config = check_database_connectivity()
    data_ok = check_data_availability(db_config)
    env_ok = check_environment_initialization(db_config)
    reward_ok = check_reward_calculation()
    config_ok = check_configuration()
    gpu_ok = check_gpu_availability()
    estimate_training_time(db_config)
    
    # Summary
    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    
    checks = [
        ("Database connectivity", db_ok),
        ("Data availability", data_ok),
        ("Environment initialization", env_ok),
        ("Reward calculation", reward_ok),
        ("Configuration", config_ok),
        ("GPU availability", gpu_ok)
    ]
    
    passed = sum(1 for _, status in checks if status)
    total = len(checks)
    
    for check_name, status in checks:
        status_str = "✓ PASSED" if status else "✗ FAILED"
        print(f"{check_name:.<40} {status_str}")
    
    print(f"\nOverall: {passed}/{total} checks passed")
    
    if passed < total:
        print("\n⚠️  ISSUES DETECTED - Please fix the failed checks before training")
        if not config_ok:
            print("\nIMPORTANT: Update config.py to use 'options_data' as the database name")
    else:
        print("\n✓ All checks passed - System is ready for training!")

if __name__ == "__main__":
    main()